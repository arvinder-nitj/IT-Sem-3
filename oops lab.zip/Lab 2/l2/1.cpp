#include<iostream>
using namespace std;

void id()
{ cout<<"\nCoded by : Arvinder Singh\nRoll No  : 18124004\n------------------------------";}

int main(void)
{
    id();
    int a;
    cout<<"\nEnter a number :";
    cin>>a;

    if(a==0)
            cout<<"\nEntered number is neither positive nor negative i.e. ZERO";
    else if (a&1)
        cout<<"\nEntered number is odd";
    else
        cout<<"\nEntered number is even";
    return 0;
}
