#include<iostream>
using namespace std;

void id(){ cout<<"\nCoded by : Arvinder Singh\nRoll No  : 18124004\n------------------------------";}

int main(void)
{
    id();
    int a,c,sum=0;
    cout<<endl<<"Enter a number :";
    cin>>a;
    c=a;

    cout<<endl<<"Entered number in words is :"<<endl;

    while(c!=0)
    {
        sum=sum*10 + c%10;
        c/=10;
    }

    while(sum!=0)
    {
      c=sum%10;
      sum/=10;

      switch(c)
      {

      case 1:
        cout<<"One ";
         break;
     case 2:
        cout<<"Two ";
        break;
    case 3:
        cout<<"Three ";
        break;
    case 4:
        cout<<"Four ";
        break;
    case 5:
        cout<<"Five ";
        break;
    case 6:
        cout<<"Six ";
        break;
    case 7:
        cout<<"Seven ";
        break;
    case 8:
        cout<<"Eight ";
        break;
    case 9:
        cout<<"Nine ";
        break;
  default:
        cout<<"Zero ";

      }
    }
    cout<<endl;

    return 0;
}
