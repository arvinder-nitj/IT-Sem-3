#include<iostream>
#include<math.h>
using namespace std;

void id()
{ cout<<"\nCoded by : Arvinder Singh\nRoll No  : 18124004\n------------------------------";}

int is_arm(int n,int digit)
{
    int num=n,sum=0;
    while(num!=0)
    {
        sum=sum+pow(num%10,digit);
        num/=10;
    }

    if(sum==n)
        return 1;
    else
        return 0;
}

int main(void)
{
    id();
    int digit,check;
    cout<<"\nArmstrong numbers from 1 to 1000 are:"<<endl;

   for(int i=1;i<=1000;i++)
    {
        digit=floor(log10(i))+1;
        check=is_arm(i,digit);
        if(check==1)
            cout<<i<<endl;
    }

    return 0;
}
