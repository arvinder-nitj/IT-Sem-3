#include<iostream>
using namespace std;

void id()
{ cout<<"\nCoded by : Arvinder Singh\nRoll No  : 18124004\n------------------------------";}

int main(void)
{
    id();
    int a;
   cout<<"\nEnter  number of rows you want to print :";
    cin>>a;
    cout<<endl;

    for(int i=1;i<=a;i++)
    {

      {

        for(int j=i;j!=0;j--)
            cout<<j<<" ";
    }
       cout<<endl;
    }


    return 0;
}
