#include <iostream>
using namespace std;

void get(int *a,int *b)
{
    cout<<endl<<"Enter length and breadth of reactangle : ";
    cin>>*a>>*b;
}

inline int area(int l,int b=1)
{
    return l*b;
}

inline float peri(int l,int b)
{
    return 2*(l+b);
}

int main(void)
{
    int choice;
    int l,b;

            get(&l,&b);
    do
    {
        cout<<endl<<endl<<"Choose from following:";
        cout<<endl<<"1. To calculate area of rectangle";
        cout<<endl<<"2. To calculate perimeter of rectangle";
        cout<<endl<<"3. To change length and breadth";
        cout<<endl<<"4. To exit"<<endl;
        cin>>choice;

        switch(choice)
        {
        case 1:
            cout<<endl<<"Area of rectangle is :"<<area(l,b);
            break;
        case 2:
            cout<<endl<<"Perimeter of rectangle is :"<<peri(l,b);
            break;
        case 4:
            break;
        case 3:
            cout<<endl;
            get(&l,&b);
        default :
            cout<<endl<<"Enter a valid option";
        }
    }while(choice!=4);

 return 0;
}
