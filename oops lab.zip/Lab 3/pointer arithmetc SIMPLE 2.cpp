#include <iostream>
using namespace std;

int main ()
{
    int value = 7;
    int *t,*ptr = &value;

    std::cout <<" ptr :"<< ptr << '\n';
    std::cout << ptr+1 << '\n';
    t=++ptr;
    std::cout <<"++ptr "<<ptr<< '\n';
    std::cout <<"--ptr :"<< --ptr << '\n';
    std::cout <<"t-ptr :"<< t-ptr << '\n';

    return 0;
}
