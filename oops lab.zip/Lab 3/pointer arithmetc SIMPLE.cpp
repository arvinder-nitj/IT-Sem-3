#include <iostream>
using namespace std;
const int size = 4;

int main () {
   int  arr[size] = {1,2,3,4};
   int  *ptr,choice;
      ptr = arr;

            cout<<endl<<endl<<"Pointer increment:"<<endl;

              for (int i = 0; i < size; i++)
                {
                 cout << "Address of arr[" << i << "] = ";
                 cout << ptr << endl;

                 cout << "Value of arr[" << i << "] = ";
                 cout << *ptr << endl;
                 ptr++;
              }


            cout<<endl<<endl<<"Pointer decrement:"<<endl;
             ptr = &arr[size-1];

              for (int i = size; i > 0; i--) {
                 cout << "Address of arr[" << i << "] = ";
                 cout << ptr << endl;

                 cout << "Value of arr[" << i << "] = ";
                 cout << *ptr << endl;
                 ptr--;
              }

            cout<<endl<<"Pointer comparison:"<<endl;
            for(int i=0; ptr <= &arr[size - 1];ptr++,i++ )
            {
             cout << "Address of arr[" << i << "] = ";
             cout << ptr << endl;

             cout << "Value of arr[" << i << "] = ";
             cout << *ptr << endl;
            }

            cout<<endl<<"Pointer subtraction:"<<endl;
            int *ptr2;
            ptr=&arr[0];
            ptr2=&arr[1];
            cout<<endl<<"Size  of element in array :" <<(ptr2-ptr)<<endl;
            cout<<sizeof(arr[0]);

   return 0;
   }
