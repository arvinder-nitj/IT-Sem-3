#include <iostream>
using namespace std;

void id()
{ cout<<"\nCoded by : Arvinder Singh\nRoll No  : 18124004\n------------------------------";}

const int size = 4;

int main () {
   int  arr[size] = {1,2,3,4};
   int  *ptr,choice;
   do
    {
        cout<<endl<<endl<<"Choose from following:";
        cout<<endl<<"1. Pointer increment";
        cout<<endl<<"2. Pointer decrement";
        cout<<endl<<"3.pointer comparison";
        cout<<endl<<"4.pointer subtraction";
        cout<<endl<<"5. To exit"<<endl;
        cin>>choice;

        switch(choice)
        {
        case 1:
            ptr = arr;

              cout<<endl<<endl<<"Pointer increment:"<<endl;

              for (int i = 0; i < size; i++)
                {
                 cout << "Address of arr[" << i << "] = ";
                 cout << ptr << endl;

                 cout << "Value of arr[" << i << "] = ";
                 cout << *ptr << endl;
                 ptr++;
              }

            break;

        case 2:
            cout<<endl<<endl<<"Pointer decrement:"<<endl;
             ptr = &arr[size-1];

              for (int i = size; i > 0; i--) {
                 cout << "Address of arr[" << i << "] = ";
                 cout << ptr << endl;

                 cout << "Value of arr[" << i << "] = ";
                 cout << *ptr << endl;
                 ptr--;
              }
            break;


        case 3:
            cout<<endl<<"Pointer comparison:"<<endl;
            for(int i=0; ptr <= &arr[size - 1];ptr++,i++ )
            {
             cout << "Address of arr[" << i << "] = ";
             cout << ptr << endl;

             cout << "Value of arr[" << i << "] = ";
             cout << *ptr << endl;
            }
            break;
        case 4:
            cout<<endl<<"Pointer subtraction:"<<endl;
            int *ptr2;
            ptr=&arr[0];
            ptr2=&arr[1];
            cout<<endl<<"Size  of element in array :" <<(ptr2-ptr)<<endl;
            cout<<sizeof(arr[0]);
            break;

        case 5:
            break;

        default :
            cout<<endl<<"Enter a valid option";
        }
    }while(choice!=5);






   return 0;
   }
