#include <iostream>
using

extern int count;

void write_extern(void) {
 cout << "Count is " << count << std::endl;
}


int count ;
extern void write_extern();

main() {
   count = 5;
   write_extern();
}
