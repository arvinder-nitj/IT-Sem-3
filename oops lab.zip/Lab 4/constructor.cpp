#include<iostream>
using namespace std;

class complex
{
private:
    float a,b;
public:
    complex(){}
    complex(float m,float n=0)
    {
        a=m;
        b=n;
    }
    complex(complex &p2) {a = p2.a; b = p2.b; }

    friend void display(complex);
    friend complex sum(complex,complex);
};

void display (complex c)
{
    cout<<c.a<<" + j"<<c.b<<endl;
}

complex sum(complex p1,complex p2)
{
  complex s;
  s.a=p1.a+p2.a;
  s.b=p1.b+p2.b;
  return (s);
}

int main(void)
{
    complex result,p1(3,4);
    complex p2=p1;

    cout<<"The two complex numbers are:\n";
    display(p1);
    cout<<"\n";
    display(p2);
    cout<<"\n";

    result=sum(p1,p2);
    cout<<"\nSum of two complex numbers is:";
    display(result);

    return 0;
}
