#include<iostream>
using namespace std;

 int sum (int a,int b)
 {
     return(a+b);
 }

 void swap(int *a,int *b)
 {
     (*a)^=(*b)^=(*a)^=(*b);
 }

 int main(void)
 {
     int a,b;
     cout<<"Enter two numbers :";
     cin>>a>>b;
     cout<<"\n";

     cout<<"**** Example of call by value ****";
     cout<<"\nSum of two numbers is : "<<sum(a,b);

     cout<<"\n**** Example of call by reference ****";
     cout<<"\nNumbers before swapping are : "<<a<<" and "<<b;
     if(a!=b)
     swap(&a,&b);
     cout<<"\nNumbers after swapping are : "<<a<<" and "<<b;
     return 0;
 }
