#include<iostream>
using namespace std;
int x;
void autoStorageClass()
{

	cout<<"\nDemonstrating auto class\n\n";
	auto int a = 32;
	cout<<"Value of the variable 'a' declared as auto:\n"<<a<<endl;
}

void registerStorageClass()
{

	cout<<"\nDemonstrating register class\n\n";
	register char b = 'G';
	cout<<"Value of the variable 'b'declared as register:"<<b;

}

void externStorageClass()
{

	cout<<"\nDemonstrating extern class\n\n";
	extern int x;
	cout<<"Value of the variable 'x' declared as extern: "<<x<<endl;
	x = 2;
	cout<<"Modified value of the variable 'x' declared as extern: "<<x;
}

void staticStorageClass()
{
	int i = 0;

	cout<<"\nDemonstrating static class\n\n";

	cout<<"Declaring 'y' as static inside the loop.\nBut this declaration will occur only once as 'y' is static.\n If not, then every time the value of 'y' will be the declared value 5 as in the case of variable 'p'\n";

	cout<<"\nLoop started:\n";

	for (i = 1; i < 2; i++) {

		static int y = 5;
		int p = 10;
		y++;
		p++;
		cout<<"\nThe value of 'y',declared as static, in "<<i
			<<" iteration is :" <<y<<endl;

		cout<<"The value of non-static variable 'p',in "<<i <<"iteration is "<<p<<endl;
	}

	cout<<"\nLoop ended:\n";

}

int main()
{

	cout<<"A program to demonstrate Storage Classes\n\n";
    autoStorageClass();
    registerStorageClass();
    externStorageClass();
	staticStorageClass();
	cout<<"\n\nStorage Classes demonstrated";

	return 0;
}

