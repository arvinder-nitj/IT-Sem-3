#include <iostream>
using namespace std;
class constructor
{
	static int count;
public:
	constructor ()
	{
		cout<<"object no. "<<count<<" defined"<<endl;
		count++;
	}
	~constructor()
	{
		count--;
		cout<<"object no. "<<count<<" destroyed"<<endl;
	}
};
int constructor::count = 1;
int main()
{
	cout<<"\nentering main"<<endl;
	constructor a,b,c,d;
	{
		cout<<"\nentering block"<<endl;
		constructor e,f;
		cout<<"\nexiting block"<<endl;
	}
	cout<<"\nexiting main"<<endl;
	return 0;
}
