#include <iostream>
using namespace std;
class test
{
	int real, imag;
public:
	void getdata(int a,int b) {real=a; imag=b;}
	void putdata() {cout<<real<<" + i("<<imag<<")"<<endl;}
	test friend sum(test&,test&); 
};
test sum(test &a,test &b)
{
	test c;
	c.getdata(a.real+b.real,a.imag+b.imag);
	return c;
}
int main()
{
	test a,b,c;
	a.getdata(5,6);
	b.getdata(3,-4);
	cout<<"a= ";
	a.putdata();
	cout<<"b= ";
	b.putdata();
	cout<<"a+b= ";
	c= sum(a,b);
	c.putdata();
	return 0;
}
