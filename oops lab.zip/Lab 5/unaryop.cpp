#include <iostream>
using namespace std;
class test
{
	int real, imag;
public:
	void getdata(int a,int b) {real=a; imag=b;}
	void putdata() {cout<<real<<"+ i("<<imag<<")"<<endl;}
	void operator-();
};
void test::operator-()
{
	real = -real;
	imag = -imag;
}
int main()
{
	test a;
	a.getdata(5,6);
	cout<<"a= ";
	a.putdata();
	cout<<"-a =";
	-a;
	a.putdata();
	return 0;
}