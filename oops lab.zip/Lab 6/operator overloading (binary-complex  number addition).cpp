#include<iostream>
using namespace std;

class complex
{
    float real,im;
public:
    complex(){}
    complex(float a,float b=0)
    {
        real=a;
        im=b;
    }
    void display(){cout<<real<<" +"<<im<<"i";}
    complex operator+(complex);

};

complex complex ::operator+(complex  a)
{
    //complex temp;
    //temp.real=real+a.real;
    //temp.im=im+a.im;
    return complex(real+a.real,im+a.im);
}

int main()
{
    complex a(3.14,2),b(3),c;
    c=a+b;

    cout<<"\nFirst complex number is (a) : ";
    a.display();
    cout<<"\nSecond complex number is (b) : ";
    b.display();

    cout<<"\nSum of two complex numbers (c=a+b) is : ";
    c.display();

    cout<<endl;

    return 0;
}
