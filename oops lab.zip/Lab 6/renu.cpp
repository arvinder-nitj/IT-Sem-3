#include<bits/stdc++.h>
using namespace std;
int main() {

	// Write your code here
    int n;
    cin>>n;
    int *doubt=new int[n];
    int point,k,i,j,ren=0;
    for(int i=0;i<n;i++)
        cin>>doubt[i];

    cin>>point>>k;
    while(k--)
    {
        ren=0;
        cin>>i>>j;
        for(--i,--j;i<=j;i++)
        {
          ren+=doubt[i];
        }
        cout<<ren*point<<endl;
    }
    return 0;
}
