#include<iostream>
#include<STRING.h>
using namespace std;

class STRING
{
 int len;
 char *ptr;
 public:
     STRING()
     {len=0;ptr=NULL;}
     STRING(const char *s);
     STRING(const STRING &s);
     ~STRING(){delete ptr;}
     friend void show(const STRING s);
     friend STRING operator+(const STRING &a,const STRING &b);
     friend bool operator<=(const STRING &a,const STRING &b);
};

void show(const STRING s) {cout<<s.ptr;}

STRING :: STRING(const char *s)
     {
         len=strlen(s);
         ptr=new char[len+1];
         strcpy(ptr,s);
     }
STRING :: STRING (const STRING &str)
     {
         len=str.len;
         ptr=new char[len+1];
         strcpy(ptr,str.ptr);
     }


STRING operator+(const STRING &a,const STRING &b)
{
    STRING temp;
    temp.len=a.len+b.len;
    temp.ptr=new char[temp.len+1];
    strcpy(temp.ptr,a.ptr);
    strcat(temp.ptr,b.ptr);
    return temp;
}

bool operator<=(const STRING &a,const STRING &b)
{
    if (a.len<=b.len)
        return 1;
    else
        return 0;
}

int main()
{
    STRING s1="Hi ";
    STRING s2="World";
    STRING s3=s1+s2;
    cout<<"\nString 1 is : ";
    show(s1);
    cout<<"\nString 2 is : ";
    show(s2);
     //s3=s1+s2;
    cout<<"\nConcatination : ";show(s3);
    cout<<endl<<endl;

    if (s1<=s2)
    {
        show(s1);
        cout<<" is smaller in size than ";
        show(s2);
    }
   else
    {
        show(s1);
        cout<<" is larger in size than ";
        show(s2);
    }
    return 0;
}
