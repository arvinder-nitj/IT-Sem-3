#include <iostream>
using namespace std;

class base {
public:
    void display1()
    {
        cout << "\nBase class content.";
    }
};
class derived : public base {
public:
    void display2()
    {
        cout << "1st derived class content.";
    }
};

class derived2 : public derived {
    void display3()
    {
        cout << "\n2nd Derived class content.";
    }
};

int main()
{
    derived2 D;
    //D.display3();
    D.display2();
    D.display1();
}
