#include<iostream>
using namespace std;

class  base
	{
		private: int x;
			float y;
		public :
		    virtual void getdata( )=0;
			virtual void display( )=0;
	};
class dev : public base
	{
		private:  int roll;
			 char name[20];
		public : void getdata( );
			void  display( );
	};
void base :: getdata( )  {  }
void base :: display( )   {  }

void dev :: getdata( )
	{
		cout<<"\nEnter Roll of  the Student :";
		cin>> roll;
		cout<<"\nEnter name of  the student :";
		cin>>name;
        }
void dev :: display( )
	{
		cout<<"\nName is :"<<name<<endl;
		cout<<"\nRoll no is :"<<roll <<endl;
	}

int main( )
	{
		base * ptr;
		dev obj;
		ptr = &obj;
		ptr -> getdata( );
		ptr -> display( );
	return 0;
	}
