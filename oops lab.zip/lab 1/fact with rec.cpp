#include<iostream>
using namespace std;

int fact(int n)
{
    if (n==0||n==1)
        return 1;
    else
        return n*fact(n-1);
}
int main(void)
{
    int n,i;
    cout<<"\nEnter number :";
    cin>>n;
    i=fact(n);
    cout<<"\nFactorial of the number is:" <<i<<endl;

    return 0;

}
