#include<iostream>
using namespace std;

int main(void)
{
    int n,num,fact=1;
    cout<<"\nEnter number :";
    cin>>n;
    num=n;

    while(num!=1)
    {
        fact*=num;
        num--;
    }

    cout<<"\nFactorial of the number is:" <<fact<<endl;

    return 0;
}
