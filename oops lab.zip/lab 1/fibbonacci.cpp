#include<iostream>
using namespace std;

int fib(int n)
{
    if (n==0||n==1)
        return n;
    else
        return (fib(n-1)+fib(n-2));
}
int main(void)
{
    int n,i=0;
    cout<<"\nEnter number of terms (upto whch you want to print fibonacci series) :";
    cin>>n;
    cout<<endl<<"\nFibonacci series upto " <<n <<" terms :"<<endl;

    while(i<n)
    {
        cout<<fib(i)<<"  ";
        i++;
    }
    cout<<endl;
    return 0;
}
