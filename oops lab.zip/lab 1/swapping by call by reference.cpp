#include<iostream>
using namespace std;

void swap(int &m,int &n)
{
   int temp;
   temp=m;
   m=n;
   n=temp;
}
int main(void)
{
    int m,n;
    cout<<"\nEnter number two numbers :";
    cin>>m>>n;
    cout<<endl<<"Numbers before swapping are :"<<m<<" and "<<n<<endl;
    swap(m,n);
    cout<<endl<<"Numbers after swapping are  :"<<m<<" and "<<n<<endl;
    return 0;
}
